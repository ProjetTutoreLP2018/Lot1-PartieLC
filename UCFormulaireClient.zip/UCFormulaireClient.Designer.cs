﻿namespace lot1
{
	partial class UCFormulaireClient
	{
		/// <summary> 
		/// Variable nécessaire au concepteur.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Nettoyage des ressources utilisées.
		/// </summary>
		/// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Code généré par le Concepteur de composants

		/// <summary> 
		/// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
		/// le contenu de cette méthode avec l'éditeur de code.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.IndiceRepetition = new System.Windows.Forms.ComboBox();
			this.Complement = new System.Windows.Forms.TextBox();
			this.NumeroVoie = new System.Windows.Forms.NumericUpDown();
			this.label26 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.Ville = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.Adresse = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.CodePostal = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.BoutonValider = new System.Windows.Forms.Button();
			this.BoutonAnnuler = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.FonctionRepresentant = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.SexeRepresentant = new System.Windows.Forms.ComboBox();
			this.TelephonePortableRepresentant = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.PrenomRepresentant = new System.Windows.Forms.TextBox();
			this.CourrielRepresentant = new System.Windows.Forms.TextBox();
			this.NomRepresentant = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.TelephoneRepresentant = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.VolumesAnnuels = new System.Windows.Forms.NumericUpDown();
			this.OrganisationComptable = new System.Windows.Forms.TextBox();
			this.label22 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.CA = new System.Windows.Forms.NumericUpDown();
			this.label20 = new System.Windows.Forms.Label();
			this.NumeroSiret = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.LieuImmatriculation = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.SiteInternet = new System.Windows.Forms.TextBox();
			this.DateImmatriculation = new System.Windows.Forms.DateTimePicker();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.FormeJuridique = new System.Windows.Forms.ComboBox();
			this.NomOrganisation = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.Effectif = new System.Windows.Forms.NumericUpDown();
			this.DateCreation = new System.Windows.Forms.DateTimePicker();
			this.label1 = new System.Windows.Forms.Label();
			this.ESSOui = new System.Windows.Forms.RadioButton();
			this.label3 = new System.Windows.Forms.Label();
			this.ESSJnsp = new System.Windows.Forms.RadioButton();
			this.ESSNon = new System.Windows.Forms.RadioButton();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
			this.préremplirAutomatiquementToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.préremplirAvecUnFichierClientToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumeroVoie)).BeginInit();
			this.groupBox3.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.VolumesAnnuels)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.CA)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.Effectif)).BeginInit();
			this.toolStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.IndiceRepetition);
			this.groupBox2.Controls.Add(this.Complement);
			this.groupBox2.Controls.Add(this.NumeroVoie);
			this.groupBox2.Controls.Add(this.label26);
			this.groupBox2.Controls.Add(this.label25);
			this.groupBox2.Controls.Add(this.label24);
			this.groupBox2.Controls.Add(this.Ville);
			this.groupBox2.Controls.Add(this.label23);
			this.groupBox2.Controls.Add(this.Adresse);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.CodePostal);
			this.groupBox2.Controls.Add(this.label12);
			this.groupBox2.Location = new System.Drawing.Point(467, 46);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(400, 183);
			this.groupBox2.TabIndex = 51;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Adresse de l\'entité";
			// 
			// IndiceRepetition
			// 
			this.IndiceRepetition.FormattingEnabled = true;
			this.IndiceRepetition.Items.AddRange(new object[] {
            "bis",
            "ter",
            "quater"});
			this.IndiceRepetition.Location = new System.Drawing.Point(313, 24);
			this.IndiceRepetition.Name = "IndiceRepetition";
			this.IndiceRepetition.Size = new System.Drawing.Size(69, 21);
			this.IndiceRepetition.TabIndex = 27;
			// 
			// Complement
			// 
			this.Complement.Location = new System.Drawing.Point(100, 85);
			this.Complement.Name = "Complement";
			this.Complement.Size = new System.Drawing.Size(282, 20);
			this.Complement.TabIndex = 6;
			// 
			// NumeroVoie
			// 
			this.NumeroVoie.Location = new System.Drawing.Point(100, 25);
			this.NumeroVoie.Name = "NumeroVoie";
			this.NumeroVoie.Size = new System.Drawing.Size(73, 20);
			this.NumeroVoie.TabIndex = 4;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(8, 88);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(74, 13);
			this.label26.TabIndex = 3;
			this.label26.Text = "Complément : ";
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(38, 59);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(54, 13);
			this.label25.TabIndex = 2;
			this.label25.Text = "Adresse : ";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(190, 27);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(106, 13);
			this.label24.TabIndex = 1;
			this.label24.Text = "Indice de répétition : ";
			// 
			// Ville
			// 
			this.Ville.Location = new System.Drawing.Point(100, 145);
			this.Ville.Name = "Ville";
			this.Ville.Size = new System.Drawing.Size(282, 20);
			this.Ville.TabIndex = 26;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(37, 27);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(53, 13);
			this.label23.TabIndex = 0;
			this.label23.Text = "Numéro : ";
			// 
			// Adresse
			// 
			this.Adresse.Location = new System.Drawing.Point(100, 56);
			this.Adresse.Name = "Adresse";
			this.Adresse.Size = new System.Drawing.Size(282, 20);
			this.Adresse.TabIndex = 22;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(16, 119);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(72, 13);
			this.label11.TabIndex = 23;
			this.label11.Text = "Code postal : ";
			// 
			// CodePostal
			// 
			this.CodePostal.Location = new System.Drawing.Point(100, 116);
			this.CodePostal.Name = "CodePostal";
			this.CodePostal.Size = new System.Drawing.Size(116, 20);
			this.CodePostal.TabIndex = 24;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(56, 148);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(35, 13);
			this.label12.TabIndex = 25;
			this.label12.Text = "Ville : ";
			// 
			// BoutonValider
			// 
			this.BoutonValider.Location = new System.Drawing.Point(792, 459);
			this.BoutonValider.Name = "BoutonValider";
			this.BoutonValider.Size = new System.Drawing.Size(75, 23);
			this.BoutonValider.TabIndex = 50;
			this.BoutonValider.Text = "Valider";
			this.BoutonValider.UseVisualStyleBackColor = true;
			this.BoutonValider.Click += new System.EventHandler(this.BoutonValider_ClickAsync);
			// 
			// BoutonAnnuler
			// 
			this.BoutonAnnuler.Location = new System.Drawing.Point(711, 459);
			this.BoutonAnnuler.Name = "BoutonAnnuler";
			this.BoutonAnnuler.Size = new System.Drawing.Size(75, 23);
			this.BoutonAnnuler.TabIndex = 49;
			this.BoutonAnnuler.Text = "Annuler";
			this.BoutonAnnuler.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.FonctionRepresentant);
			this.groupBox3.Controls.Add(this.label9);
			this.groupBox3.Controls.Add(this.label7);
			this.groupBox3.Controls.Add(this.SexeRepresentant);
			this.groupBox3.Controls.Add(this.TelephonePortableRepresentant);
			this.groupBox3.Controls.Add(this.label4);
			this.groupBox3.Controls.Add(this.PrenomRepresentant);
			this.groupBox3.Controls.Add(this.CourrielRepresentant);
			this.groupBox3.Controls.Add(this.NomRepresentant);
			this.groupBox3.Controls.Add(this.label13);
			this.groupBox3.Controls.Add(this.label14);
			this.groupBox3.Controls.Add(this.label17);
			this.groupBox3.Controls.Add(this.TelephoneRepresentant);
			this.groupBox3.Controls.Add(this.label16);
			this.groupBox3.Location = new System.Drawing.Point(467, 236);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(400, 217);
			this.groupBox3.TabIndex = 48;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Représentant de l\'entité/Contact";
			// 
			// FonctionRepresentant
			// 
			this.FonctionRepresentant.FormattingEnabled = true;
			this.FonctionRepresentant.Items.AddRange(new object[] {
            "Président(e)-Directeur(trice) Général",
            "Directeur(trice) des Ressources Humaines",
            "Directeur(trice) des Systèmes d\'Information",
            "Directeur(trice) Administratif et Financier",
            "Commercial",
            "Technicien informatique",
            "Comptable",
            "Expert-Comptable",
            "Développeur informatique",
            "Logisticien",
            "Chef de produit",
            "Chef de projet",
            "Juriste"});
			this.FonctionRepresentant.Location = new System.Drawing.Point(104, 132);
			this.FonctionRepresentant.Name = "FonctionRepresentant";
			this.FonctionRepresentant.Size = new System.Drawing.Size(290, 21);
			this.FonctionRepresentant.TabIndex = 48;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(32, 135);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(57, 13);
			this.label9.TabIndex = 47;
			this.label9.Text = "Fonction : ";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(56, 108);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(40, 13);
			this.label7.TabIndex = 46;
			this.label7.Text = "Sexe : ";
			// 
			// SexeRepresentant
			// 
			this.SexeRepresentant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.SexeRepresentant.FormattingEnabled = true;
			this.SexeRepresentant.Items.AddRange(new object[] {
            "M",
            "F"});
			this.SexeRepresentant.Location = new System.Drawing.Point(104, 105);
			this.SexeRepresentant.Name = "SexeRepresentant";
			this.SexeRepresentant.Size = new System.Drawing.Size(121, 21);
			this.SexeRepresentant.TabIndex = 42;
			// 
			// TelephonePortableRepresentant
			// 
			this.TelephonePortableRepresentant.Location = new System.Drawing.Point(148, 186);
			this.TelephonePortableRepresentant.Name = "TelephonePortableRepresentant";
			this.TelephonePortableRepresentant.Size = new System.Drawing.Size(246, 20);
			this.TelephonePortableRepresentant.TabIndex = 40;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(26, 189);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(108, 13);
			this.label4.TabIndex = 41;
			this.label4.Text = "Téléphone portable : ";
			// 
			// PrenomRepresentant
			// 
			this.PrenomRepresentant.Location = new System.Drawing.Point(104, 49);
			this.PrenomRepresentant.Name = "PrenomRepresentant";
			this.PrenomRepresentant.Size = new System.Drawing.Size(290, 20);
			this.PrenomRepresentant.TabIndex = 39;
			// 
			// CourrielRepresentant
			// 
			this.CourrielRepresentant.Location = new System.Drawing.Point(104, 77);
			this.CourrielRepresentant.Name = "CourrielRepresentant";
			this.CourrielRepresentant.Size = new System.Drawing.Size(290, 20);
			this.CourrielRepresentant.TabIndex = 36;
			// 
			// NomRepresentant
			// 
			this.NomRepresentant.Location = new System.Drawing.Point(90, 21);
			this.NomRepresentant.Name = "NomRepresentant";
			this.NomRepresentant.Size = new System.Drawing.Size(304, 20);
			this.NomRepresentant.TabIndex = 28;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(44, 24);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(38, 13);
			this.label13.TabIndex = 27;
			this.label13.Text = "Nom : ";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(43, 52);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(52, 13);
			this.label14.TabIndex = 29;
			this.label14.Text = "Prénom : ";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(41, 80);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(51, 13);
			this.label17.TabIndex = 35;
			this.label17.Text = "Courriel : ";
			// 
			// TelephoneRepresentant
			// 
			this.TelephoneRepresentant.Location = new System.Drawing.Point(122, 159);
			this.TelephoneRepresentant.Name = "TelephoneRepresentant";
			this.TelephoneRepresentant.Size = new System.Drawing.Size(272, 20);
			this.TelephoneRepresentant.TabIndex = 30;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(26, 162);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(86, 13);
			this.label16.TabIndex = 33;
			this.label16.Text = "Téléphone fixe : ";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.VolumesAnnuels);
			this.groupBox1.Controls.Add(this.OrganisationComptable);
			this.groupBox1.Controls.Add(this.label22);
			this.groupBox1.Controls.Add(this.label21);
			this.groupBox1.Controls.Add(this.CA);
			this.groupBox1.Controls.Add(this.label20);
			this.groupBox1.Controls.Add(this.NumeroSiret);
			this.groupBox1.Controls.Add(this.label15);
			this.groupBox1.Controls.Add(this.LieuImmatriculation);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.SiteInternet);
			this.groupBox1.Controls.Add(this.DateImmatriculation);
			this.groupBox1.Controls.Add(this.label18);
			this.groupBox1.Controls.Add(this.label19);
			this.groupBox1.Controls.Add(this.FormeJuridique);
			this.groupBox1.Controls.Add(this.NomOrganisation);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.Effectif);
			this.groupBox1.Controls.Add(this.DateCreation);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.ESSOui);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.ESSJnsp);
			this.groupBox1.Controls.Add(this.ESSNon);
			this.groupBox1.Location = new System.Drawing.Point(19, 46);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(441, 407);
			this.groupBox1.TabIndex = 47;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Entité";
			// 
			// VolumesAnnuels
			// 
			this.VolumesAnnuels.Location = new System.Drawing.Point(142, 371);
			this.VolumesAnnuels.Name = "VolumesAnnuels";
			this.VolumesAnnuels.Size = new System.Drawing.Size(194, 20);
			this.VolumesAnnuels.TabIndex = 50;
			// 
			// OrganisationComptable
			// 
			this.OrganisationComptable.Location = new System.Drawing.Point(142, 335);
			this.OrganisationComptable.Name = "OrganisationComptable";
			this.OrganisationComptable.Size = new System.Drawing.Size(263, 20);
			this.OrganisationComptable.TabIndex = 49;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(36, 371);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(96, 13);
			this.label22.TabIndex = 48;
			this.label22.Text = "Volumes annuels : ";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(0, 335);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(127, 13);
			this.label21.TabIndex = 47;
			this.label21.Text = "Organisation comptable : ";
			// 
			// CA
			// 
			this.CA.Location = new System.Drawing.Point(140, 113);
			this.CA.Name = "CA";
			this.CA.Size = new System.Drawing.Size(138, 20);
			this.CA.TabIndex = 46;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(26, 118);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(96, 13);
			this.label20.TabIndex = 45;
			this.label20.Text = "Chiffres d\'affaires : ";
			// 
			// NumeroSiret
			// 
			this.NumeroSiret.Location = new System.Drawing.Point(140, 195);
			this.NumeroSiret.Name = "NumeroSiret";
			this.NumeroSiret.Size = new System.Drawing.Size(281, 20);
			this.NumeroSiret.TabIndex = 44;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(90, 205);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(48, 13);
			this.label15.TabIndex = 43;
			this.label15.Text = "SIRET : ";
			// 
			// LieuImmatriculation
			// 
			this.LieuImmatriculation.Location = new System.Drawing.Point(142, 301);
			this.LieuImmatriculation.Name = "LieuImmatriculation";
			this.LieuImmatriculation.Size = new System.Drawing.Size(263, 20);
			this.LieuImmatriculation.TabIndex = 42;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(6, 305);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(116, 13);
			this.label6.TabIndex = 41;
			this.label6.Text = "Lieu d\'immatriculation : ";
			// 
			// SiteInternet
			// 
			this.SiteInternet.Location = new System.Drawing.Point(139, 142);
			this.SiteInternet.Name = "SiteInternet";
			this.SiteInternet.Size = new System.Drawing.Size(282, 20);
			this.SiteInternet.TabIndex = 40;
			// 
			// DateImmatriculation
			// 
			this.DateImmatriculation.Location = new System.Drawing.Point(170, 265);
			this.DateImmatriculation.Name = "DateImmatriculation";
			this.DateImmatriculation.Size = new System.Drawing.Size(200, 20);
			this.DateImmatriculation.TabIndex = 28;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(6, 274);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(119, 13);
			this.label18.TabIndex = 27;
			this.label18.Text = "Date d\'immatriculation : ";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(54, 145);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(73, 13);
			this.label19.TabIndex = 37;
			this.label19.Text = "Site Internet : ";
			// 
			// FormeJuridique
			// 
			this.FormeJuridique.DisplayMember = "SA SAS ";
			this.FormeJuridique.FormattingEnabled = true;
			this.FormeJuridique.Items.AddRange(new object[] {
            "EI",
            "EIRL",
            "EURL",
            "SA",
            "SARL",
            "SAS",
            "SASU",
            "SC",
            "SCA",
            "SCIC",
            "SCOP",
            "SNC"});
			this.FormeJuridique.Location = new System.Drawing.Point(139, 53);
			this.FormeJuridique.Name = "FormeJuridique";
			this.FormeJuridique.Size = new System.Drawing.Size(163, 21);
			this.FormeJuridique.TabIndex = 21;
			// 
			// NomOrganisation
			// 
			this.NomOrganisation.Location = new System.Drawing.Point(139, 24);
			this.NomOrganisation.Name = "NomOrganisation";
			this.NomOrganisation.Size = new System.Drawing.Size(282, 20);
			this.NomOrganisation.TabIndex = 8;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(2, 27);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(117, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Nom de l\'organisation : ";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(35, 56);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(87, 13);
			this.label8.TabIndex = 4;
			this.label8.Text = "Forme juridique : ";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(82, 86);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(49, 13);
			this.label5.TabIndex = 7;
			this.label5.Text = "Effectif : ";
			// 
			// Effectif
			// 
			this.Effectif.Location = new System.Drawing.Point(140, 83);
			this.Effectif.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
			this.Effectif.Name = "Effectif";
			this.Effectif.Size = new System.Drawing.Size(120, 20);
			this.Effectif.TabIndex = 17;
			// 
			// DateCreation
			// 
			this.DateCreation.Location = new System.Drawing.Point(170, 230);
			this.DateCreation.Name = "DateCreation";
			this.DateCreation.Size = new System.Drawing.Size(200, 20);
			this.DateCreation.TabIndex = 15;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(90, 176);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(43, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "ESS ? :";
			// 
			// ESSOui
			// 
			this.ESSOui.AutoSize = true;
			this.ESSOui.Location = new System.Drawing.Point(140, 172);
			this.ESSOui.Name = "ESSOui";
			this.ESSOui.Size = new System.Drawing.Size(41, 17);
			this.ESSOui.TabIndex = 12;
			this.ESSOui.TabStop = true;
			this.ESSOui.Text = "Oui";
			this.ESSOui.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(29, 237);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(98, 13);
			this.label3.TabIndex = 3;
			this.label3.Text = "Date de création  : ";
			// 
			// ESSJnsp
			// 
			this.ESSJnsp.AutoSize = true;
			this.ESSJnsp.Location = new System.Drawing.Point(276, 172);
			this.ESSJnsp.Name = "ESSJnsp";
			this.ESSJnsp.Size = new System.Drawing.Size(92, 17);
			this.ESSJnsp.TabIndex = 14;
			this.ESSJnsp.TabStop = true;
			this.ESSJnsp.Text = "Je ne sais pas";
			this.ESSJnsp.UseVisualStyleBackColor = true;
			// 
			// ESSNon
			// 
			this.ESSNon.AutoSize = true;
			this.ESSNon.Location = new System.Drawing.Point(208, 172);
			this.ESSNon.Name = "ESSNon";
			this.ESSNon.Size = new System.Drawing.Size(45, 17);
			this.ESSNon.TabIndex = 13;
			this.ESSNon.TabStop = true;
			this.ESSNon.Text = "Non";
			this.ESSNon.UseVisualStyleBackColor = true;
			// 
			// toolStrip1
			// 
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton2});
			this.toolStrip1.Location = new System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(886, 25);
			this.toolStrip1.TabIndex = 52;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// toolStripDropDownButton2
			// 
			this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.préremplirAutomatiquementToolStripMenuItem1,
            this.préremplirAvecUnFichierClientToolStripMenuItem1});
			this.toolStripDropDownButton2.Image = global::lot1.Properties.Resources.Pen2_16x;
			this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
			this.toolStripDropDownButton2.Size = new System.Drawing.Size(96, 22);
			this.toolStripDropDownButton2.Text = "Pré-remplir";
			// 
			// préremplirAutomatiquementToolStripMenuItem1
			// 
			this.préremplirAutomatiquementToolStripMenuItem1.Image = global::lot1.Properties.Resources.Pen2_16x;
			this.préremplirAutomatiquementToolStripMenuItem1.Name = "préremplirAutomatiquementToolStripMenuItem1";
			this.préremplirAutomatiquementToolStripMenuItem1.Size = new System.Drawing.Size(246, 22);
			this.préremplirAutomatiquementToolStripMenuItem1.Text = "Pré-remplir automatiquement";
			this.préremplirAutomatiquementToolStripMenuItem1.ToolTipText = "Pré-remplir automatiquement";
			this.préremplirAutomatiquementToolStripMenuItem1.Click += new System.EventHandler(this.préremplirAutomatiquementToolStripMenuItem1_Click);
			// 
			// préremplirAvecUnFichierClientToolStripMenuItem1
			// 
			this.préremplirAvecUnFichierClientToolStripMenuItem1.Image = global::lot1.Properties.Resources.UploadFile_16x;
			this.préremplirAvecUnFichierClientToolStripMenuItem1.Name = "préremplirAvecUnFichierClientToolStripMenuItem1";
			this.préremplirAvecUnFichierClientToolStripMenuItem1.Size = new System.Drawing.Size(246, 22);
			this.préremplirAvecUnFichierClientToolStripMenuItem1.Text = "Pré-remplir avec un fichier client";
			this.préremplirAvecUnFichierClientToolStripMenuItem1.ToolTipText = "Pré-remplir avec un fichier client";
			this.préremplirAvecUnFichierClientToolStripMenuItem1.Click += new System.EventHandler(this.préremplirAvecUnFichierClientToolStripMenuItem1_Click);
			// 
			// UCFormulaireClient
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.BoutonValider);
			this.Controls.Add(this.BoutonAnnuler);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox1);
			this.Name = "UCFormulaireClient";
			this.Size = new System.Drawing.Size(886, 488);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumeroVoie)).EndInit();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.VolumesAnnuels)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.CA)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.Effectif)).EndInit();
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.ComboBox IndiceRepetition;
		private System.Windows.Forms.TextBox Complement;
		private System.Windows.Forms.NumericUpDown NumeroVoie;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.TextBox Ville;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.TextBox Adresse;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox CodePostal;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Button BoutonValider;
		private System.Windows.Forms.Button BoutonAnnuler;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.ComboBox FonctionRepresentant;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox SexeRepresentant;
		private System.Windows.Forms.TextBox TelephonePortableRepresentant;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox PrenomRepresentant;
		private System.Windows.Forms.TextBox CourrielRepresentant;
		private System.Windows.Forms.TextBox NomRepresentant;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TextBox TelephoneRepresentant;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.NumericUpDown VolumesAnnuels;
		private System.Windows.Forms.TextBox OrganisationComptable;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.NumericUpDown CA;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.TextBox NumeroSiret;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox LieuImmatriculation;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox SiteInternet;
		private System.Windows.Forms.DateTimePicker DateImmatriculation;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.ComboBox FormeJuridique;
		private System.Windows.Forms.TextBox NomOrganisation;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown Effectif;
		private System.Windows.Forms.DateTimePicker DateCreation;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton ESSOui;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.RadioButton ESSJnsp;
		private System.Windows.Forms.RadioButton ESSNon;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
		private System.Windows.Forms.ToolStripMenuItem préremplirAutomatiquementToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem préremplirAvecUnFichierClientToolStripMenuItem1;
	}
}
