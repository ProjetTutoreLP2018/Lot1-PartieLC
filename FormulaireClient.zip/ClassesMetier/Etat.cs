﻿using System;
using System.Collections.Generic;

namespace WindowsFormsApp1.modele
{
    public partial class Etat
    {
        public int IdEtat { get; set; }
        public string LibelleEtat { get; set; }
    }
}
