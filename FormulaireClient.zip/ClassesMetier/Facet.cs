﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lot1
{
    public class Facet
    {
        public string name { get; set; }
        public string path { get; set; }
        public int count { get; set; }
        public string state { get; set; }
    }
}
