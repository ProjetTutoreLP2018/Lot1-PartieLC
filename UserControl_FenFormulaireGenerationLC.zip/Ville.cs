﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lot1
{
    class Ville
    {
            public string nom { get; set; }
            /*public string code { get; set; }
            public string codeDepartement { get; set; }
            public string codeRegion { get; set; }
            public List<string> codesPostaux { get; set; }
            public int population { get; set; }*/
    }
}
